import argparse
import shutil

import numpy as np
from matplotlib import pyplot as plt

from helicopter import Helicopter
from utilities import ISA, display_text, parse_toml_params
import warnings

warnings.filterwarnings("ignore")

params = {
    "figure.figsize": [9, 6],
    "axes.labelsize": 14,
    "axes.titlesize": 18,
    "axes.titlepad": 15,
    "font.size": 16,
    "legend.fontsize": 12,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "text.usetex": True if shutil.which("latex") else False,
    "font.family": "serif",
    "xtick.minor.visible": True,
    "ytick.minor.visible": True,
    "xtick.top": True,
    "ytick.left": True,
    "ytick.right": True,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "xtick.minor.size": 2.5,
    "xtick.major.size": 5,
    "ytick.minor.size": 2.5,
    "ytick.major.size": 5,
    "axes.axisbelow": True,
    "figure.dpi": 200,
}
plt.rcParams.update(params)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Plot figures for slides based on the given parameters"
    )
    parser.add_argument(
        "--params",
        type=str,
        default="data/params.toml",
        help="path/to/the/parameters/file.toml of the given values (assignment problem statement)",
    )
    parser.add_argument(
        "--plots_dir",
        type=str,
        default="images",
        help="path/to/the/directory to save the plots",
    )
    args = parser.parse_args()

plots_dir = args.plots_dir
params = parse_toml_params(args.params)
hel = Helicopter(params)
ALPHA_FUSELAGE = hel.alpha_fuselage

atmosphere = ISA()

atmosphere_params = (
    atmosphere.temperature(params["helicopter"]["altitude"]),
    atmosphere.pressure(params["helicopter"]["altitude"]),
    atmosphere.density(params["helicopter"]["altitude"]),
    atmosphere.speed_of_sound(params["helicopter"]["altitude"]),
    atmosphere.dynamic_viscosity(params["helicopter"]["altitude"]),
)

### 3.2 Observations and reasoning for the behavior of FX, FY, FZ, MX, MY, and MZ of the vehicle with
### variation in theta_(o,m), beta_o, beta_1c + theta_1s , beta_1s - theta_1c and theta_(o,t)

TRIM_CONDITIONS = [
    2.255,
    1.5,
    2.7,
    2.025,
]  # theta_(o,m), theta_1c, theta_1s, theta_(o,t)

display_text(f"TRIM FOR 50 km/hr", c="green")

hel.cal_median_forward_flight_params(TRIM_CONDITIONS, verbose=True, N_ITERS=100)

xlabels = [
    r"Main Rotor Collective $(\theta_{o,m})$",
    r"Lateral Cyclic $(\theta_{1c})$",
    r"Longitudinal Cyclic $(\theta_{1s})$",
    r"Tail Rotor Collective $(\theta_{o,t})$",
]
for i, (p, xlabel) in enumerate(zip(TRIM_CONDITIONS, xlabels)):
    x = np.linspace(p - 0.5, p + 0.5, 20)
    fig, ax = plt.subplots(1, 2, figsize=(10, 5))
    for _x in x:
        _trim_conditions = TRIM_CONDITIONS.copy()
        _trim_conditions[i] = float(_x)
        force, moment = hel.cal_median_forward_flight_params(
            _trim_conditions, hel.forward_velocity
        )
        ax[0].scatter(
            _x,
            force[0],
            c="C0",
            s=100,
            label="Fx",
            edgecolors="w",
            alpha=0.6,
        )
        ax[0].scatter(
            _x,
            -force[1],
            c="C1",
            s=100,
            label="Fy",
            edgecolors="w",
            alpha=0.6,
        )  # hub frame to body frame
        ax[0].scatter(
            _x,
            -force[2],
            c="C2",
            s=100,
            label="Fz",
            edgecolors="w",
            alpha=0.6,
        )  # hub frame to body frame
        ax[1].scatter(
            _x,
            moment[0],
            c="C0",
            s=100,
            label="Mx",
            edgecolors="w",
            alpha=0.6,
        )
        ax[1].scatter(
            _x,
            -moment[1],
            c="C1",
            s=100,
            label="My",
            edgecolors="w",
            alpha=0.6,
        )  # hub frame to body frame
        ax[1].scatter(
            _x,
            -moment[2],
            c="C2",
            s=100,
            label="Mz",
            edgecolors="w",
            alpha=0.6,
        )  # hub frame to body frame
    ylim_0 = ax[0].get_ylim()
    ylim_1 = ax[1].get_ylim()
    ax[0].set_ylim(*ylim_0)
    ax[1].set_ylim(*ylim_1)
    ax[0].vlines(
        TRIM_CONDITIONS[i],
        ylim_0[0],
        ylim_0[1],
        colors="k",
        linestyles="--",
        label="Trim",
    )
    ax[1].vlines(
        TRIM_CONDITIONS[i],
        ylim_1[0],
        ylim_1[1],
        colors="k",
        linestyles="--",
        label="Trim",
    )
    ax[0].set_xlabel(xlabel)
    ax[0].set_ylabel("Force")
    handles, labels = ax[0].get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax[0].legend(by_label.values(), by_label.keys())
    ax[0].set_title("Forces")

    ax[1].set_xlabel(xlabel)
    ax[1].set_ylabel("Moment")
    handles, labels = ax[1].get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax[1].legend(by_label.values(), by_label.keys())
    ax[1].set_title("Moments")
    fig.tight_layout()
    fig.savefig(f"images/{xlabel.split(' $')[0].replace(' ', '_')}.png")


### 5.1 Maximum Speed based on blade stall at 2000 m AMSL

MAX_VELOCITY = 18.05  # m/s

print("\n\n")
display_text(
    f"Maximum Speed based on blade stall: {MAX_VELOCITY*18/5:.2f} km/hr", c="green"
)

STALL_TRIM = [2.06, 3.5, 2.7, 2.25]  # theta_(o,m), theta_1c, theta_1s, theta_(o,t)
hel.cal_median_forward_flight_params(
    STALL_TRIM, MAX_VELOCITY, verbose=True, N_ITERS=100
)


### 5.2. Maximum Speed based on power requirement at 2000 m AMSL

MAX_VELOCITY = 25  # m/s

print("\n\n")
display_text(
    f"Maximum Speed based on power requirement: {MAX_VELOCITY*18/5:.2f} km/hr",
    c="green",
)

POWER_TRIM = [1.7, 8.25, 8.5, 6.5]  # theta_(o,m), theta_1c, theta_1s, theta_(o,t)
hel.alpha_fuselage = np.deg2rad(3.5)
hel.cal_median_forward_flight_params(
    POWER_TRIM, MAX_VELOCITY, verbose=True, N_ITERS=100
)
hel.alpha_fuselage = ALPHA_FUSELAGE


### 5.3. Maximum Range at 2000 m AMSL

hel.cal_median_forward_flight_params(TRIM_CONDITIONS, verbose=False, N_ITERS=100)

time = hel.fuel / hel.fuel_burn_rate  # minutes
range = hel.forward_velocity * time * 60 / 1000  # km

print("\n\n")
display_text(f"Maximum Range: {range:.2f} km", c="green")
print("\n\n")

### 5.4. Maximum Endurance at 2000 m AMSL

# this max endurance would be at hover, so set alpha_fuselage, forward_velocity to 0
hel = Helicopter(
    params
)  # reset the helicopter to get rid of previous forward flight values

HOVER_TRIM = [2.678, 0.051, 2.25, 2.15]  # theta_(o,m), theta_1c, theta_1s, theta_(o,t)
hel.alpha_fuselage = np.deg2rad(0)
display_text("TRIM FOR HOVER", c="green")
hel.cal_median_forward_flight_params(HOVER_TRIM, 0, verbose=True, N_ITERS=100)
hel.alpha_fuselage = ALPHA_FUSELAGE

time = hel.fuel / hel.fuel_burn_rate / 60  # hours

print()
display_text(f"Endurance: {time:.2f} hours", c="green")
