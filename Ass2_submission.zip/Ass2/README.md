# README
General Instructions
===
> Use python version $\geq$ 3.10.0
### Required Imports
- `numpy`
- `matplotlib`
- `toml` : This code uses a TOML file for storing helicopter design configuration in a python dictionary format.
- `scipy` : uses `fsolve()` from `scipy.optimse` module
- `pandas` :  To load airfoil characteristics, engine performance and atomosphere model as `DataFrame`.

### Design Parameters
Please look at `data/params.toml` for  design details of the **Team Helicopter**. The user can edit this file to incorporate custom designs or alternatively pass in their own `.toml` file by simply adding `--params` followed by the path to the `.toml` file to the below python commands.

### Execution
1. Running GUI :  The simulator is run using the following command:
	
   ```console
	python3 simulator.py
	```

2. Generating plots :  Run the following command in terminal to generate plots used to analyse effects of control inputs
   
   ```console
   python3 plot_team_slides.py
   ```

4. Trimming the helicopter : For manual trim, GUI is not the best option due to slow reaction. Hence in the file `helicopter.py` one must manually edit the following snippet section to vary the velocity $V_{\infty}$ and control inputs $\theta_{0,m} ,\theta_{1c},\theta_{1s}$ and $\theta_{0,t}$
   
   ```python
   # values are in degrees
    main_rotor_collective = 0.792 # Enter your value here
    lateral_cyclic = 0.0	       # Enter your value here
    longitudinal_cyclic = 0.5     # Enter your value here
    tail_rotor_collective = 0.9   # Enter your value here

    forward_velocity = 13.88      # change from default of 50 * 5/18 m/s
   ```

   After putting in the control inputs, run the file using the following bash command to get the net moments and forces along with parameters like coning angles $\beta_0,\beta_{1s},\beta_{1c}$ and $\alpha_{TPP}$.
   
   ```console
   python3 helicopter.py
   ```

   Adjust values and run again untill the moment and force residues are minimised to a satisfactory level.

### Sample Outputs

```console
> python simulator.py
No output is generated. The GUI will open up and you can interact with the helicopter model.
```

```console
> python helicopter.py

Main Rotor Collective:           2.255
Main Rotor Lateral Cyclic:       1.5
Main Rotor Longitudinal Cyclic:  2.7
Tail Rotor Collective:           2.025
Forward Velocity (m/s):          13.88888888888889


Net force (Hub Frame):    [ -0.38499 -10.13223   0.34199]
Net moment (Hub Frame):   [-2.62034  5.16624  1.53964]

Net force (Body Frame):   [-0.38499 10.13223 -0.34199]
Net moment (Body Frame):  [-2.62034 -5.16624 -1.53964]
Main Rotor Thrust:        [   4.19637   24.2045  1962.72082]
Tail Rotor Thrust:        34.33673
Fuselage Drag:            38.82890
Mean of Max Alpha:        3.73763
Alpha TPP:                1.15580
beta_o:                   0.29862
beta_1c:                  0.15178
beta_1s:                  0.65955
Power:                    16375.05085
Power Available:          77040.00000
```

```console
> python plot_team_slides.py
#---------------------------#
#-----TRIM FOR 50 km/hr-----#
#---------------------------#

Main Rotor Collective:           2.255
Main Rotor Lateral Cyclic:       1.5
Main Rotor Longitudinal Cyclic:  2.7
Tail Rotor Collective:           2.025
Forward Velocity (m/s):          13.88888888888889


Net force (Hub Frame):    [ -0.38499 -10.13223   0.34199]
Net moment (Hub Frame):   [-2.62034  5.16624  1.53964]

Net force (Body Frame):   [-0.38499 10.13223 -0.34199]
Net moment (Body Frame):  [-2.62034 -5.16624 -1.53964]
Main Rotor Thrust:        [   4.19637   24.2045  1962.72082]
Tail Rotor Thrust:        34.33673
Fuselage Drag:            38.82890
Mean of Max Alpha:        3.73763
Alpha TPP:                1.15580
beta_o:                   0.29862
beta_1c:                  0.15178
beta_1s:                  0.65955
Power:                    16375.05085
Power Available:          77040.00000



#---------------------------------------------------------#
#-----Maximum Speed based on blade stall: 64.98 km/hr-----#
#---------------------------------------------------------#

Main Rotor Collective:           2.06
Main Rotor Lateral Cyclic:       3.5
Main Rotor Longitudinal Cyclic:  2.7
Tail Rotor Collective:           2.25
Forward Velocity (m/s):          18.05


Net force (Hub Frame):    [-15.1851  -12.64952   4.62843]
Net moment (Hub Frame):   [ -2.68134  22.81238 -23.69354]

Net force (Body Frame):   [-15.1851   12.64952  -4.62843]
Net moment (Body Frame):  [ -2.68134 -22.81238  23.69354]
Main Rotor Thrust:        [  16.14375   27.20048 1967.47414]
Tail Rotor Thrust:        39.85001
Fuselage Drag:            65.58047
Mean of Max Alpha:        12.08831
Alpha TPP:                1.58292
beta_o:                   0.28631
beta_1c:                  0.58165
beta_1s:                  0.65043
Power:                    21555.36217
Power Available:          77040.00000



#---------------------------------------------------------------#
#-----Maximum Speed based on power requirement: 90.00 km/hr-----#
#---------------------------------------------------------------#

Main Rotor Collective:           1.7
Main Rotor Lateral Cyclic:       8.25
Main Rotor Longitudinal Cyclic:  8.5
Tail Rotor Collective:           6.5
Forward Velocity (m/s):          25


Net force (Hub Frame):    [  0.08162 -77.5942    1.53772]
Net moment (Hub Frame):   [ 32.87646  -1.08253 -57.80588]

Net force (Body Frame):   [ 0.08162 77.5942  -1.53772]
Net moment (Body Frame):  [32.87646  1.08253 57.80588]
Main Rotor Thrust:        [   5.87537   69.63034 1967.55844]
Tail Rotor Thrust:        147.22455
Fuselage Drag:            125.80564
Mean of Max Alpha:        25.63850
Alpha TPP:                4.63408
beta_o:                   0.13225
beta_1c:                  1.13834
beta_1s:                  1.25800
Power:                    77376.61658
Power Available:          77040.00000



#----------------------------------#
#-----Maximum Range: 418.80 km-----#
#----------------------------------#



#------------------------#
#-----TRIM FOR HOVER-----#
#------------------------#

Main Rotor Collective:           2.678
Main Rotor Lateral Cyclic:       0.051
Main Rotor Longitudinal Cyclic:  2.25
Tail Rotor Collective:           2.15
Forward Velocity (m/s):          0


Net force (Hub Frame):    [  0.21928 -27.39687  -0.21868]
Net moment (Hub Frame):   [22.38705 -0.05426 -6.12724]

Net force (Body Frame):   [ 0.21928 27.39687  0.21868]
Net moment (Body Frame):  [22.38705  0.05426  6.12724]
Main Rotor Thrust:        [   0.21928    9.97499 1961.78132]
Tail Rotor Thrust:        37.37186
Fuselage Drag:            0.00000
Mean of Max Alpha:        2.36567
Alpha TPP:                nan
beta_o:                   0.28509
beta_1c:                  0.00637
beta_1s:                  0.28908
Power:                    18604.04328
Power Available:          77040.00000

#-------------------------------#
#-----Endurance: 7.51 hours-----#
#-------------------------------#
```

### Code Structure
We have the following Structure of our code

`Ass2/`
- `data/`  
	- `NACA0012.csv` : Airfoil characteristics
	- `isa.csv` : Atmosphere data
	- `turboprop_data.csv` : Engine data
	- `params.toml` : Here is where you input the helicopter **design parameters** and **mission specifications**.
- `images/` : contains all the generated plots and figures for presentation
- `presentation/` 
	- `pres.pdf`  : Team slides
	- Remaining are latex code
- `README.md` : You are here :smiley:
- `helicopter.py`: File defining helicopter class build upon blade class. Used for computations in `simulation.py` and `plot_team_slides.py`
- `utilities.py` :  contains definition for  blade class that use different theories and other utility functions
- `simulatior.py`: Runs the GUI
- `plot_team_slides.py` : plots the performance graphs as requested by the problem statement. 

## Credits and Acknowledgements
This code is designed for computing flight performance and mission of standard helicopters using low fidelity models like _BEMT_. We approach the problem in a geometric framework as described in the team slides :  `presentation/pres.pdf`. The code is a combined effort of 

 1. Ravi Kumar               (Roll no. 210010052)
 2. Vighnesh J.R.            (Roll no. 210010073)
 3. Shreyas N.B.             (Roll no. 210010061)
 4. Mayank Ghritlahre        (Roll no. 210010040)

Furthermore we would like to convey special acknowledgements to professor Dhwanil Shukla of Department of Aerospace Engineering, IIT Bombay , for providing us with the theoretical knowledge and opportunity to build this tool as an assignment for his course AE 667, rotary wing aerodynamics.
