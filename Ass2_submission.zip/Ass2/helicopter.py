import argparse

import numpy as np
import numpy.typing as npt

from utilities import (
    ISA,
    Blade,
    TurboTechEngine,
    color,
    g,
    parse_toml_params,
)


class Helicopter:
    """
    Helicopter class to simulate the helicopter dynamics

    Args:
    -----
    params: dict
        Dictionary containing the parameters of the helicopter
    """

    def __init__(
        self,
        params: dict,
    ) -> None:
        main_rotor_params: dict = params["rotors"]["main"]
        tail_rotor_params: dict = params["rotors"]["tail"]
        self.main_rotor = Blade(main_rotor_params)
        self.tail_rotor = Blade(tail_rotor_params)
        self.engine = TurboTechEngine()

        ### Constants ###
        self.payload: float = params["helicopter"]["payload"]
        self.empty_weight: float = params["helicopter"]["empty_weight"]
        self.cg_to_main_rotor: npt.NDArray = np.array(
            params["helicopter"]["cg_to_main_rotor"]
        )
        self.cg_to_tail_rotor: npt.NDArray = np.array(
            params["helicopter"]["cg_to_tail_rotor"]
        )
        self.alpha_fuselage: float = float(
            np.deg2rad(params["helicopter"]["alpha_fuselage"])
        )
        self.flat_plate_area: float = params["helicopter"]["flat_plate_area"]
        self.fuel_density: float = params["helicopter"]["fuel_density"]
        self.dt = 0.5

        ### Variables ###
        self.psi_o: float = 0
        self.fuel: float = params["helicopter"]["fuel"]
        self.altitude: float = params["helicopter"]["altitude"]
        self.forward_velocity: float = params["helicopter"]["forward_velocity"] * 5 / 18
        self.mass: float = self.empty_weight + self.payload + self.fuel
        self.atmosphere = ISA()

    def update_atmosphere(
        self, altitude: float
    ) -> tuple[float, float, float, float, float]:
        """
        Update the atmosphere parameters. This is to be called at every time step

        Args:
        altitude: float
            Altitude of the helicopter

        Returns:
        tuple[float, float, float, float, float]
            Temperature, Pressure, Density, Speed of sound, Dynamic viscosity
        """
        return (
            self.atmosphere.temperature(altitude),
            self.atmosphere.pressure(altitude),
            self.atmosphere.density(altitude),
            self.atmosphere.speed_of_sound(altitude),
            self.atmosphere.dynamic_viscosity(altitude),
        )

    def update_helicopter(
        self,
        collective_pitch: float,
        lateral_cyclic: float,
        longitudinal_cyclic: float,
        tail_rotor_collective: float,
        forward_velocity: float = 1,
        dt: float | None = None,
    ) -> None:
        """
        Update the helicopter parameters at every time step.
        Calculates the net thrust, moments, power, fuel burn rate, etc.
        
        (Currently the fuel is not being updated)
        
        Args:
        collective_pitch: float
            Collective pitch of the main rotor
        lateral_cyclic: float
            Lateral cyclic pitch of the main rotor
        longitudinal_cyclic: float
            Longitudinal cyclic pitch of the main rotor
        tail_rotor_collective: float
            Collective pitch of the tail rotor
        forward_velocity: float
            Forward velocity of the helicopter
        dt: float
            Time step

        Returns:
        None
        """
        if not dt:
            dt = self.dt
        V_infty = forward_velocity * np.array(
            [-np.cos(self.alpha_fuselage), 0, -np.sin(self.alpha_fuselage)]
        )
        self.atmosphere_params = self.update_atmosphere(self.altitude)
        self.main_rotor.get_atmosphere(self.atmosphere_params)
        self.main_rotor.forward_flight_update_params(
            collective_pitch,
            lateral_cyclic,
            longitudinal_cyclic,
            self.psi_o,
            V_infty,
        )
        self.main_rotor.forward_flight_params()
        self.tail_rotor.get_atmosphere(self.atmosphere_params)
        self.tail_rotor.bemt_update_params(tail_rotor_collective, V_infty)
        self.main_rotor_thrust = self.main_rotor.thrust
        self.tail_rotor_thrust = self.tail_rotor.bemt_thrust()
        self.main_rotor_torque, self.main_rotor_power = (
            self.main_rotor.torque,
            self.main_rotor.power,
        )
        self.tail_rotor_torque, self.tail_rotor_power = (
            self.tail_rotor.bemt_torque_and_power()
        )
        self.total_power = self.main_rotor_power + self.tail_rotor_power
        self.shaft_power_available = (
            self.engine.power_delivered(
                self.altitude, self.atmosphere_params[0], self.atmosphere_params[0]
            )
            * 0.9  # 90% efficiency
            * 1000  # W to kW
        )
        self.fuel_burn_rate = (
            (self.total_power / 1000)
            * self.engine.sfc(
                self.altitude, self.atmosphere_params[0], self.atmosphere_params[0]
            )
            / 60
        )  # kg/min
        # self.fuel = self.fuel - (dt / 60) * self.fuel_burn_rate
        # self.mass = self.empty_weight + self.payload + self.fuel

    def cal_median_forward_flight_params(
        self,
        inputs: list[float],
        forward_velocity: float | None = None,
        N_ITERS: int = 10,
        verbose: bool = False,
    ) -> tuple[npt.NDArray, npt.NDArray]:
        """
        Calculate the median of the forces and moments acting on the helicopter
        by calculating forces, moments etc N_ITERS times and taking the median.
        Azimuthal angle is updated by 360/N_ITERS at each iteration to ensure full disk coverage.

        Args:
        inputs: list[float]
            List of inputs to the helicopter: [main rotor collective, lateral cyclic, longitudinal cyclic, tail rotor collective]
        forward_velocity: float
            Forward velocity of the helicopter
        N_ITERS: int
            Number of iterations to calculate the median
        verbose: bool
            Print the forces and moments
        
        Returns:
        tuple[npt.NDArray, npt.NDArray]
            Net force and net moment acting on the helicopter
        """
        forward_velocity = (
            forward_velocity if forward_velocity is not None else self.forward_velocity
        )
        (
            median_force,
            median_moment,
            median_main_thrust,
            median_tail_thrust,
            median_tpp,
            median_beta,
            median_alpha_tpp,
            max_alpha,
            median_power,
        ) = ([], [], [], [], [], [], [], [], [])

        for _ in range(N_ITERS):
            (
                collective_pitch,
                lateral_cyclic,
                longitudinal_cyclic,
                tail_rotor_collective,
            ) = inputs

            self.update_helicopter(
                collective_pitch,
                lateral_cyclic,
                longitudinal_cyclic,
                tail_rotor_collective,
                forward_velocity,
            )

            fuselage_drag = (
                0.5
                * self.atmosphere_params[2]
                * forward_velocity**2
                * self.flat_plate_area
            )

            net_force = (
                self.main_rotor_thrust
                + np.array([0, -self.tail_rotor_thrust, 0])
                + self.mass
                * g
                * np.array(
                    [np.sin(self.alpha_fuselage), 0, -np.cos(self.alpha_fuselage)]
                )
                - fuselage_drag
                * np.array(
                    [np.cos(self.alpha_fuselage), 0, np.sin(self.alpha_fuselage)]
                )
            )

            # Moment in vector format m = r_i x F_i + \tau_main + \tau_tail
            net_moment = (
                np.cross(self.cg_to_main_rotor, self.main_rotor_thrust)
                + np.cross(
                    self.cg_to_tail_rotor, np.array([0, -self.tail_rotor_thrust, 0])
                )
                + self.main_rotor_torque
                + np.array([0, self.tail_rotor_torque, 0])
            )

            median_force.append(net_force)
            median_moment.append(net_moment)
            median_main_thrust.append(self.main_rotor_thrust)
            median_tail_thrust.append(self.tail_rotor_thrust)
            median_tpp.append(self.main_rotor.tpp)
            median_beta.append(self.main_rotor.beta)
            max_alpha.append(np.max(self.main_rotor.linear_twist - self.main_rotor.phi))
            median_power.append(self.total_power)
            (
                median_alpha_tpp.append(self.main_rotor.alpha_tpp)
                if hasattr(self.main_rotor, "alpha_tpp")
                else median_alpha_tpp.append(np.nan)
            )

            self.psi_o += 360 / N_ITERS

        net_force = np.median(median_force, axis=0)
        net_moment = np.median(median_moment, axis=0)
        main_thrust = np.median(median_main_thrust, axis=0)
        tail_thrust = np.median(median_tail_thrust, axis=0)
        tpp = np.median(median_tpp, axis=0)
        beta_o = np.median(median_beta)
        alpha_tpp = np.median(median_alpha_tpp, axis=0)
        alpha = np.mean(max_alpha)
        power = np.median(median_power, axis=0)
        if verbose:
            print("\nMain Rotor Collective:          ", collective_pitch)
            print("Main Rotor Lateral Cyclic:      ", lateral_cyclic)
            print("Main Rotor Longitudinal Cyclic: ", longitudinal_cyclic)
            print("Tail Rotor Collective:          ", tail_rotor_collective)
            print("Forward Velocity (m/s):         ", forward_velocity)
            print("\n")
            print("Net force (Hub Frame):   ", net_force)
            print("Net moment (Hub Frame):  ", net_moment)
            print()
            print(
                "Net force (Body Frame):  ",
                np.array([net_force[0], -net_force[1], -net_force[2]]),
            )  # hub frame to body frame
            print(
                "Net moment (Body Frame): ",
                np.array([net_moment[0], -net_moment[1], -net_moment[2]]),
            )  # hub frame to body frame
            print(f"Main Rotor Thrust:        {main_thrust}")
            print(f"Tail Rotor Thrust:        {tail_thrust:.5f}")
            print(f"Fuselage Drag:            {fuselage_drag:.5f}")

            if alpha > self.main_rotor.STALL_ANGLE:
                print(
                    f"{color.RED}Mean of Max Alpha:        {np.rad2deg(alpha):.5f}{color.END}"
                )
            else:
                print(f"Mean of Max Alpha:        {np.rad2deg(alpha):.5f}")

            print(f"Alpha TPP:                {np.rad2deg(alpha_tpp):.5f}")
            print(f"beta_o:                   {np.rad2deg(beta_o):.5f}")
            print(
                f"beta_1c:                  {np.rad2deg(np.arctan2(tpp[0], tpp[2])):.5f}"
            )
            print(
                f"beta_1s:                  {np.rad2deg(np.arctan2(tpp[1], tpp[2])):.5f}"
            )

            if power > self.shaft_power_available:
                print(f"{color.RED}Power:                    {power:.5f}{color.END}")
            else:
                print(f"Power:                    {power:.5f}")
            print(f"Power Available:          {self.shaft_power_available:.5f}")

        return net_force, net_moment

    def gui_forces_and_moments(
        self,
        collective_pitch: float,
        lateral_cyclic: float,
        longitudinal_cyclic: float,
        tail_rotor_collective: float,
        forward_velocity: float,
    ) -> tuple[dict, dict]:
        """
        Calculate the forces and moments acting on the helicopter

        Args:
        collective_pitch: float
            Collective pitch of the main rotor
        lateral_cyclic: float
            Lateral cyclic pitch of the main rotor
        longitudinal_cyclic: float
            Longitudinal cyclic pitch of the main rotor
        tail_rotor_collective: float
            Collective pitch of the tail rotor
        forward_velocity: float
            Forward velocity of the helicopter

        Returns:
        tuple[dict, dict]
            Forces and moments acting on the helicopter, along x, y, z axes
        """
        forces = {"TIME": np.array([]), "x": [], "y": [], "z": []}
        moments = {"TIME": np.array([]), "x": [], "y": [], "z": []}
        TIME = np.arange(0, 10, self.dt)
        for _ in range(len(TIME)):
            net_force, net_moment = self.cal_median_forward_flight_params(
                [
                    collective_pitch,
                    lateral_cyclic,
                    longitudinal_cyclic,
                    tail_rotor_collective,
                ],
                forward_velocity,
            )

            forces["x"].append(net_force[0])
            forces["y"].append(-net_force[1])  # hub frame to body frame
            forces["z"].append(-net_force[2])  # hub frame to body frame

            moments["x"].append(net_moment[0])
            moments["y"].append(-net_moment[1])  # hub frame to body frame
            moments["z"].append(-net_moment[2])  # hub frame to body frame

        forces["TIME"] = TIME
        moments["TIME"] = TIME

        return forces, moments


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Helicopter design")
    parser.add_argument(
        "--params",
        type=str,
        default="data/params.toml",
        help="path/to/the/parameters/file.toml",
    )

    args = parser.parse_args()

    hel = Helicopter(parse_toml_params(args.params))

    # values are in degrees
    main_rotor_collective = 2.255
    lateral_cyclic = 1.5
    longitudinal_cyclic = 2.7
    tail_rotor_collective = 2.025

    forward_velocity = hel.forward_velocity  # change from default of 50 * 5/18 m/s

    hel.cal_median_forward_flight_params(
        [
            main_rotor_collective,
            lateral_cyclic,
            longitudinal_cyclic,
            tail_rotor_collective,
        ],
        forward_velocity,
        verbose=True,
        N_ITERS=100,
    )
